from Funcs import *

if __name__ == "__main__":
    print("Blackjack started")
    juego()


