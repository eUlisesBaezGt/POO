from Program import *

if __name__ == '__main__':
    program()
